---
title: "술만 마시면 토하는 사람들, 그냥 주량 문제가 아닐 수 있습니다"
description: "음주 후 반복되는 구토가 왜 생기는지, 체질·위장 상태·음주 습관별 원인과 바로 실천할 수 있는 예방법·위험 신호를 쉽게 정리했습니다."
date: 2026-03-02
draft: false
tags:
  - "음주"
  - "구토"
  - "위장건강"
slug: "vomiting-after-drinking-not-just-tolerance"
coverImageUrl: "https://upload.wikimedia.org/wikipedia/commons/2/21/Wine_glass.jpg"
---

# 술만 마시면 토하는 사람들, 그냥 주량 문제가 아닐 수 있습니다

같이 술 마신 사람은 멀쩡한데 나만 꼭 토하는 사람이 있습니다. 처음엔 다들 농담처럼 말하죠. '주량이 약해서 그래.' 그런데 이상하게도 이 사람은 술 종류를 바꿔도, 조금만 빨리 마셔도, 심지어 취하기 전에 이미 속이 뒤집힙니다.

이건 단순히 술이 약한 것만으로 설명이 안 될 때가 많습니다. 알코올은 뇌만 흐리게 만드는 게 아니라 위 점막을 자극하고, 위 배출을 늦추고, 식도와 위의 경계를 느슨하게 만들고, 혈당과 수분 상태까지 흔듭니다. 결국 어떤 사람에게는 '취함'보다 먼저 '토할 준비'가 시작됩니다.

![와인잔 이미지](https://upload.wikimedia.org/wikipedia/commons/0/0f/Wine_Glass_(224989471).jpeg)
_이미지 출처: [Wikimedia Commons - Wine glass](https://commons.wikimedia.org/wiki/File:Wine%20Glass%20%28224989471%29.jpeg)_


## 핵심만 먼저

1. 술 마신 뒤 반복되는 구토는 위장 자극, 공복 음주, 빠른 속도, 체질 차이, 기존 위장 문제의 합작일 수 있습니다.
2. 빈속, 탄산 섞은 술, 짧은 시간 과음, 수면 부족 상태에서는 주량보다 훨씬 빨리 토할 수 있습니다.
3. 작은 양에도 매번 토한다면 단순 주량 이슈보다 위염, 역류, 편두통, ALDH2 체질 같은 배경을 같이 봐야 합니다.
4. 구토가 멈추지 않거나 의식이 처지고 호흡이 이상해지면 '숙취'가 아니라 응급상황 쪽으로 봐야 합니다.

## 왜 이런 일이 생길까요?

알코올은 위에 꽤 직접적으로 거칩니다. 위산 분비를 흔들고 점막을 자극해서 메스꺼움을 만들고, 위가 음식을 아래로 밀어내는 속도도 꼬이게 합니다. 그래서 속이 안 좋은 사람은 많이 취하기도 전에 먼저 울렁거립니다.

빈속 음주는 특히 문제입니다. 술이 빨리 흡수될 뿐 아니라 위 안에 완충해 줄 음식이 없어서 자극이 더 세게 들어옵니다. 여기에 달달한 칵테일, 탄산, 에너지드링크를 섞으면 속이 뒤집히는 속도는 더 빨라집니다.

체질도 무시 못 합니다. 얼굴이 쉽게 빨개지고 두근거리고 두통이 빨리 오는 사람은 술 대사 과정이 깔끔하지 않을 수 있습니다. 이런 경우 억지로 '적응'하려고 밀어 붙이면 주량이 늘기보다 토하는 패턴만 굳어질 수 있습니다.

![음주 상황 이미지](https://upload.wikimedia.org/wikipedia/commons/2/21/Wine_glass.jpg)
_이미지 출처: [Wikimedia Commons - Wine glass](https://commons.wikimedia.org/wiki/File:Wine%20glass.jpg)_


## 사람들이 제일 많이 놓치는 포인트

### '취해서' 토하는 게 아니라 '위가 먼저 포기해서' 토할 수 있습니다

술자리에서 구토를 무조건 만취 신호로 생각하기 쉽지만, 실제로는 취하기 전부터 위가 먼저 무너지는 사람도 많습니다. 특히 평소 역류성 식도염, 위염, 과민성 장 증상이 있던 사람은 술의 자극을 더 크게 받습니다.

### 술 종류보다 마시는 속도가 더 중요할 때가 많습니다

소주냐 맥주냐보다 **짧은 시간에 얼마나 빨리 마시느냐**가 더 크게 작용합니다. 몸이 처리할 시간을 주지 않고 연달아 들이키면 혈중 알코올이 급하게 오르고, 위도 버틸 시간을 잃습니다.

### 해장하려고 커피부터 넣는 습관이 더 망칠 수 있습니다

음주 후 구토한 다음 날 공복 커피를 들이붓는 사람이 많습니다. 그런데 커피는 이미 예민해진 위를 또 건드립니다. 속쓰림, 심장 두근거림, 탈수감을 더 키워서 회복을 늦추는 경우가 흔합니다.

### 작은 양에도 매번 토하면 '나는 술 체질이 아니네'로 끝내면 안 됩니다

한두 잔에도 늘 토하거나, 술 마실 때마다 명치 통증·역류·심한 두통이 붙는다면 패턴을 기록해 보세요. 술이 원인이 아니라 **술이 숨어 있던 위장 문제를 매번 들추는 상황**일 수 있습니다.

![숙취 커피 이미지](https://upload.wikimedia.org/wikipedia/commons/4/45/A_small_cup_of_coffee.JPG)
_이미지 출처: [Wikimedia Commons - A small cup of coffee](https://commons.wikimedia.org/wiki/File:A%20small%20cup%20of%20coffee.JPG)_


## 바로 써먹는 실전 루틴

1. 술자리 전에 단백질과 탄수화물이 같이 있는 식사를 하세요. 삼겹살 고집보다, 밥과 국, 계란, 두부처럼 속에 부담 덜한 조합이 오히려 안전합니다.
2. 첫 잔부터 속도를 늦추세요. 한 번에 따라주는 속도를 따라가지 말고, 물 한 컵을 중간중간 끼워 넣어 알코올 상승 속도를 낮추는 게 핵심입니다.
3. 평소 역류나 위염이 있으면 탄산, 에너지드링크 섞은 술, 달달한 칵테일부터 먼저 피하세요. 이 조합은 구토 버튼을 빨리 누릅니다.
4. 반복 구토가 있는 사람은 술 종류, 마신 속도, 음식, 얼굴 홍조, 두통 여부를 메모해 두면 자기 패턴이 바로 보입니다.

## 이런 신호는 그냥 넘기지 마세요

- 계속 토해서 물도 못 넘기고, 소변이 거의 안 나오고, 입이 바짝 마르는 경우
- 의식이 처지거나 깨워도 반응이 둔하고, 호흡이 느려지는 경우
- 검은색 토, 피 섞인 토, 심한 복통이나 흉통이 붙는 경우
- 소량 음주에도 매번 심한 두근거림, 호흡곤란, 실신 느낌이 반복되는 경우

## 같이 읽으면 좋은 글

- [숙취 다음 날 첫 끼가 하루 컨디션을 결정합니다](/column/hangover-first-meal-strategy)
- [한국인은 커피를 이렇게 마셔야 덜 망가집니다](/column/smarter-coffee-habits-for-koreans)
- [항생제 먹는 동안 커피, 생각보다 더 위험할 수 있습니다](/column/antibiotics-and-coffee)

## 참고 자료

- [NIAAA - Understanding the Dangers of Alcohol Overdose](https://www.niaaa.nih.gov/publications/brochures-and-fact-sheets/understanding-dangers-of-alcohol-overdose)
- [NIAAA - Alcohol Metabolism](https://www.niaaa.nih.gov/publications/alcohol-metabolism)
- [MedlinePlus - Caffeine](https://medlineplus.gov/caffeine.html)
- [NHS - Heartburn and acid reflux](https://www.nhs.uk/conditions/heartburn-and-acid-reflux/)
