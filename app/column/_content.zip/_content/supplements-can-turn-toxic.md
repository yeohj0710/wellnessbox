---
title: "몸에 좋다고 계속 먹었는데, 6개월 뒤 독이 될 수도 있습니다"
description: "장기 복용 시 과잉 축적·상호작용·간독성 위험이 커질 수 있는 영양제와 주기적으로 점검해야 할 복용 기준을 정리했습니다."
date: 2026-03-08
draft: false
tags:
  - "영양제"
  - "과다복용"
  - "장기복용"
slug: "supplements-can-turn-toxic"
coverImageUrl: "https://upload.wikimedia.org/wikipedia/commons/d/db/Medication_blister_pack.jpg"
---

# 몸에 좋다고 계속 먹었는데, 6개월 뒤 독이 될 수도 있습니다

영양제의 가장 무서운 점은 몸에 해가 없다고 느끼게 만든다는 겁니다. 한 알 먹고 바로 큰일 나는 경우는 드물죠. 대신 조금씩, 길게, 조용히 쌓입니다. 그래서 사람들은 '계속 먹어도 되겠지'라고 생각합니다.

하지만 영양제에도 유통기한이 아니라 **복용기한**이 있습니다. 어떤 건 결핍 보충용으로 몇 달 쓰고 다시 점검해야 하고, 어떤 건 고함량을 오래 끌수록 오히려 신경, 간, 위장, 미네랄 균형을 건드립니다. 문제는 이 시점을 놓치면 몸이 보내는 작은 신호를 '요즘 피곤해서'로 오해하게 된다는 거예요.

![쏟아진 영양제 이미지](https://upload.wikimedia.org/wikipedia/commons/6/63/Pill_Bottle_Spilled.jpg)
_이미지 출처: [Wikimedia Commons - Pill Bottle Spilled](https://commons.wikimedia.org/wiki/File:Pill%20Bottle%20Spilled.jpg)_


## 핵심만 먼저

1. 영양제는 오래 먹는다고 점점 더 좋아지는 구조가 아닙니다. 특히 고함량 제품은 기간 관리가 중요합니다.
2. 비타민 A·D, B6, 철분, 셀레늄, 아연 같은 성분은 장기 과잉 섭취 시 문제를 만들 수 있습니다.
3. 한 제품만 먹는 줄 알았는데 종합비타민·에너지음료·단백질 제품과 성분이 겹쳐 총량이 올라가는 경우가 흔합니다.
4. 정말 필요한 성분만 남기고, 8~12주 단위로 목적을 다시 확인하는 습관이 오히려 안전합니다.

## 왜 이런 일이 생길까요?

영양제 위험은 대개 '하루 폭탄'이 아니라 '지속 누적'에서 나옵니다. 특히 지용성 비타민은 몸에 쌓일 수 있고, 물에 녹는 성분도 고함량 장기복용이면 신경·위장·피부 문제를 만들 수 있습니다.

게다가 대부분은 한 제품만 먹지 않습니다. 아침 종합비타민, 점심 에너지 음료, 운동 후 단백질, 밤엔 수면 젤리. 각각은 약해 보여도 겹치면 총량이 올라갑니다. 특히 B군, 아연, 비타민 D, 비오틴이 자주 겹칩니다.

더 무서운 건 증상이 애매하다는 점입니다. 손발 저림, 속쓰림, 변비, 메스꺼움, 두통, 입맛 변화, 피부 뒤집힘 같은 건 다들 스트레스 탓으로 넘기기 쉽습니다. 그래서 오래 가는 영양제일수록 '효과 확인'보다 '중단 시점'을 먼저 정해야 합니다.

![병 속 알약 이미지](https://upload.wikimedia.org/wikipedia/commons/1/18/Pill_Bottle_of_Assorted_Pills.JPG)
_이미지 출처: [Wikimedia Commons - Pill Bottle of Assorted Pills](https://commons.wikimedia.org/wiki/File:Pill%20Bottle%20of%20Assorted%20Pills.JPG)_


## 사람들이 제일 많이 놓치는 포인트

### 비타민 A와 D는 '몸에 좋다'가 아니라 '용량과 기간이 중요하다'입니다

지용성 비타민은 필요한 사람에게 중요하지만, 고함량을 오래 가져가면 문제가 됩니다. 특히 여러 제품에 같이 들어 있어 자신도 모르게 총량이 올라가는 경우가 흔합니다.

### B6는 '에너지 비타민' 이미지 때문에 과소평가됩니다

B군 제품을 여러 개 겹쳐 먹는 사람은 B6를 특히 조심해야 합니다. 피로 개선을 기대하고 오래 먹다가 손발 저림 같은 신경 증상을 겪는 경우가 있습니다. 물에 녹으니 괜찮겠지라는 생각이 가장 흔한 함정입니다.

### 철분과 아연은 부족할 때와 넘칠 때가 완전히 다릅니다

철분은 부족하면 힘들지만, 부족하지 않은 사람에게 활력을 보장하지 않습니다. 아연도 감기 대비용으로 무심코 오래 먹다 보면 구리 균형이 흔들릴 수 있습니다. 미네랄은 '많을수록 좋다'가 제일 틀린 분야입니다.

### 목적이 끝났으면 끊는 게 실력입니다

피곤해서 시작했는데 잠이 나아졌고 식사가 정리됐다면, 영양제를 영구 구독할 이유가 줄어듭니다. 그런데 많은 사람은 시작은 쉽고 종료는 못 합니다. 복용 목적이 사라졌는데 습관만 남은 상태가 진짜 위험합니다.

![블리스터 포장 이미지](https://upload.wikimedia.org/wikipedia/commons/1/18/Pills_in_blister_pack.jpg)
_이미지 출처: [Wikimedia Commons - Pills in blister pack](https://commons.wikimedia.org/wiki/File:Pills%20in%20blister%20pack.jpg)_


## 그래서 실제로는 이렇게 정리해야 합니다

1. **새 영양제를 시작할 때**: 시작 이유와 종료 시점을 같이 적으세요. `빈혈 교정`, `겨울철 비타민D`, `운동 기간 단백질 보완`처럼 목적이 없으면 습관만 남습니다.
2. **제품이 여러 개인 사람**: 종합비타민, 에너지음료, 단백질 분말, 젤리형까지 다 꺼내 놓고 성분 중복을 한 번 합산해 보세요. 문제는 대개 여기서 나옵니다.
3. **몇 달째 계속 먹는 사람**: 효과를 못 느껴서 더 추가하기보다, 지금 먹는 것 중 무엇을 뺄지부터 정하세요. 더하는 습관보다 정리하는 습관이 중요합니다.
4. **손발 저림, 메스꺼움, 변비, 피부 변화가 생긴 사람**: 스트레스 탓으로 넘기기 전에 최근 몇 달간 복용량과 제품 구성을 먼저 점검하세요.

## 바로 써먹는 실전 루틴

1. 복용 시작할 때 '왜 먹는지'와 '언제 다시 볼지'를 같이 적어 두세요. 예: 8주 후 재평가.
2. 종합비타민, 단일 영양제, 스포츠 보충제, 젤리형 제품까지 총량을 한 번 합산해 보세요.
3. 지용성 비타민, B6, 철분, 셀레늄, 아연은 여러 제품 중복 섭취를 특히 경계하세요.
4. 효과가 애매하거나 불편 증상이 생기면 더 추가하지 말고, 일단 빼 보면서 원인을 좁히세요.

## 이런 신호는 그냥 넘기지 마세요

- 손발 저림, 메스꺼움, 변비, 두통, 피부 이상이 복용 몇 달 뒤부터 생긴 경우
- 같은 성분이 들어간 제품을 두세 개 겹쳐 먹고 있는 경우
- 검사 없이 철분이나 고용량 지용성 비타민을 장기간 복용 중인 경우
- 기분 불안, 두근거림, 위장 불편이 있는데도 에너지 제품과 B군을 계속 올리는 경우

## 같이 읽으면 좋은 글

- [약사는 자기 가족에게도 이런 영양제는 쉽게 안 줍니다](/column/pharmacists-dont-give-these-supplements-easily)
- [가짜 영양제는 생각보다 훨씬 많습니다](/column/fake-supplement-warning-signs)
- [오메가3 아무거나 먹지 마세요, 지금 당장 버려야 할 제품도 있습니다](/column/omega3-buy-or-throw-checklist)

## 참고 자료

- [NIH ODS - Vitamin B6 Fact Sheet for Health Professionals](https://ods.od.nih.gov/factsheets/VitaminB6-HealthProfessional/)
- [FDA - Dietary Supplements](https://www.fda.gov/food/dietary-supplements)
- [NSF - Selecting Dietary and Nutritional Supplements](https://www.nsf.org/consumer-resources/articles/selecting-dietary-nutritional-supplements)
- [USP - Dietary Supplements Verification Program](https://www.usp.org/verification-services/dietary-supplements-verification-program)
